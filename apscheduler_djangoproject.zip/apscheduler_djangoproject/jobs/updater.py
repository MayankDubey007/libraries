from datetime import datetime
from apscheduler.schedulers.background import BackgroundScheduler
from .jobs import feedtester
def start():
    scheduler = BackgroundScheduler()
    # scheduler.add_job(feedtester,"cron",day_of_week="mon-sun",hour = 13,minute=20 )
    scheduler.add_job(feedtester,"interval",seconds=2 )
    scheduler.start()