
# from podcasts.models import Episode 
from django.conf import settings

def feedtester():
    print("heelo")
