from django.apps import AppConfig


class App1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app1'
    def ready(self):
        from jobs import updater
        print("app1")
        updater.start()
