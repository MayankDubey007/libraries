from django.urls import path
from .views import Findex
urlpatterns = [
    path("",Findex)
]
